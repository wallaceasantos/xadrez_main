package br.com.afsj.view;

import br.com.afsj.model.Peao;

public class IPeao extends IPeca {

	public IPeao(Peao np) {
		super(np);
	}

}
