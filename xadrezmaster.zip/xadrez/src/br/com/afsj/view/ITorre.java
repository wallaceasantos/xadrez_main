package br.com.afsj.view;

import br.com.afsj.model.Torre;

public class ITorre extends IPeca {
	
	public ITorre(Torre np) {
		super(np);
	}

}
