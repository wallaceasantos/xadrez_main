package br.com.afsj.view;

import br.com.afsj.model.Rei;

public class IRei extends IPeca {
	
	public IRei(Rei np) {
		super(np);
	}


}
