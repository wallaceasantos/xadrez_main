package br.com.afsj.view;

import br.com.afsj.model.Bispo;
import br.com.afsj.model.Rainha;

public class IRainha extends IPeca {
	
	public IRainha(Rainha np) {
		super(np);
	}


}
