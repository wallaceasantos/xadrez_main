package br.com.afsj.view;

import br.com.afsj.model.Cavalo;

public class ICavalo extends IPeca {

	public ICavalo(Cavalo np) {
		super(np);
	}

}
