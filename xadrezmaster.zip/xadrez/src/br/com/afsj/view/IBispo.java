package br.com.afsj.view;

import br.com.afsj.model.Bispo;

public class IBispo extends IPeca {
	
	public IBispo(Bispo np) {
		super(np);
	}

}
