package br.com.afsj.model;

public interface Tradutor {
	String traduzir(String palavra);
}
