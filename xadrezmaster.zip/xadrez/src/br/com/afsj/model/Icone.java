package br.com.afsj.model;

import javax.swing.Icon;

public interface Icone {
	 Icon traduzirIcone(String palavra);
}
